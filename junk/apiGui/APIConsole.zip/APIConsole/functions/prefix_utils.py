from ..imports import *
def _normalized_prefix(self) -> str:
    p = self.api_prefix_in.text().strip() or "/api"
    if not p.startswith("/"):
        p = "/" + p
    return p.rstrip("/")

def fetch_remote_endpoints(self):
    base   = self.base_combo.currentText().rstrip("/")
    prefix = self._normalized_prefix()
    # try slash version first to avoid extra redirects
    for path in (f"{base}{prefix}/endpoints/", f"{base}{prefix}/endpoints"):
        self.log_output.clear()
        logging.info(f"Fetching remote endpoints from {path}")
        try:
            data = getRequest(url=path)
            obj, is_json = safe_json(data)
            if is_json and isinstance(obj, list):
                self._populate_endpoints(obj)
                logging.info("✔ Remote endpoints loaded")
                return
        except Exception as e:
            logging.error(f"Failed to fetch endpoints from {path}: {e}")
    QMessageBox.warning(self, "Fetch Error", f"Could not load endpoints from {base}{prefix}")
def _on_api_prefix_changed(self, _txt: str):
    try:
        self.api_prefix = self._normalized_prefix()
        self.fetch_button.setText(self._fetch_label())
    except Exception as e:
        logger.info(f"**{__name__}** - _on_api_prefix_changed: {e}")
