from ..RequestThread import requestThread
from ..QTextEditLogger import qTextEditLogger
from .functions import (
    _build_ui,
    _on_fetch_response,
    _on_fetch_error,
    _fetch_label,
    fetch_remote_endpoints,
    _normalized_prefix,
    _on_api_prefix_changed,
    fetch_remote_endpoints,
    _populate_endpoints,
    on_endpoint_selected,
    _maybe_add_header_row,
    _maybe_add_body_row,
    _setup_logging,
    _collect_table_data,
    _collect_headers,
    send_request,
    _on_send_response,
    _on_send_error,
    detect_api_prefix,
    _on_detect_response,
    _on_detect_error
    )
def initFuncs(self):
    try:
        self._maybe_add_body_row = _maybe_add_body_row
        self._collect_table_data = _collect_table_data
        self._maybe_add_header_row = _maybe_add_header_row
        self._on_send_response = _on_send_response
        self._populate_endpoints = _populate_endpoints
        self.fetch_remote_endpoints = fetch_remote_endpoints
        self._on_detect_error = _on_detect_error
        self._setup_logging = _setup_logging
        self.send_request = send_request
        self._on_send_error = _on_send_error
        self.on_endpoint_selected = on_endpoint_selected
        self._build_ui = _build_ui
        self._on_fetch_error = _on_fetch_error
        self._on_api_prefix_changed = _on_api_prefix_changed
        self.fetch_remote_endpoints = fetch_remote_endpoints
        self._on_fetch_response = _on_fetch_response
        self._normalized_prefix = _normalized_prefix
        self.detect_api_prefix = detect_api_prefix
        self._on_detect_response = _on_detect_response
        self._collect_headers = _collect_headers
        self._fetch_label = _fetch_label
    except Exception as e:
        logger.info(f"{e}")
    return self
